const superagent = require('superagent');


const username = '2017114305'
const password = 'TWC1779844498'
let cookie='JSESSIONID=F468BD9663EA6CDB5413A0CF239C6DAE'
// console.log(cookie)
// console.log(random)
let header = {
    'accept': '*/*',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'zh-CN,zh;q=0.9',
    'content-length': '47',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'cookie': `${cookie};`,
    'Host': 'jwc.swjtu.edu.cn',
    'Origin': 'http://jwc.swjtu.edu.cn',
    'Referer': 'http://jwc.swjtu.edu.cn/service/login.html?version=20192',
    'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
    'x-requested-with': 'XMLHttpRequest'
}
superagent
    .get(`http://jwc.swjtu.edu.cn/vatuu/UserFramework`)
    //.query({ '_': random })
    .set(header)
    .type('form')
    .send({
        username: username,
        password: password,
        url: 'http://jwc.swjtu.edu.cn/index.html',
        returnUrl: '',
        area: '',
        ranstring: 'BMHQ'
    })
    .end(function (err, res) {
        if (err) {
            console.log(err.status);
        } else {
            console.log(res.text);
            // cb(null)
        }
    })
