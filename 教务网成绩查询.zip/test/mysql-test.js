const connection = require('../handleConnection').connection;

let username = 'tang1 ; " # -- or 1';
let password = 'TWC1234';
let sqlLine = `INSERT INTO user_info (user_name,password) VALUES( ? , ?)`;
connection.query(sqlLine,[username, password], function (error, results, fields) {
    if (error) throw error;
    console.log('The solution is: ', results);
});

// connection.end();