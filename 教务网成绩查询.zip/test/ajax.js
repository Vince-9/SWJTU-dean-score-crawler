(() => {
    let data = {
        username: '2017114305',
        password: 'TWC1779844498',
        url: $('#url').val(),
        returnUrl: $('#returnUrl').val(),
        area: $('#area').val(),
        ranstring: $("#ranstring").val()
    };
    console.log(data);
    $.ajax({
        url: '../vatuu/UserLoginAction',
        type: 'POST',
        dataType: 'json',
        data: data,
        success: function (data) {
            if (data.loginStatus === '1') {
                //alert(data.loginMsg);
                console.log(`成功`);
                // $('#loginMsg').val(data.loginMsg);
                // $('#loading').submit();
            }
            //else if(data.loginStatus === '-2'){
            //    alert(data.loginMsg);
            //    getPhotoAgain();
            //}
            else {
                alert(data.loginMsg);
                //getPhotoAgain();
            }
        }
    });
})()

