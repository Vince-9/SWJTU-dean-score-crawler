const nodemailer = require('nodemailer');

let transporter = nodemailer.createTransport({
    // host: 'smtp.ethereal.email',
    service: 'qq', // 使用了内置传输发送邮件 查看支持列表：https://nodemailer.com/smtp/well-known/
    port: 465, // SMTP 端口
    secureConnection: true, // 使用了 SSL
    auth: {
        user: '1779844498@qq.com', //你的邮箱
        // 这里密码不是qq密码，是你设置的smtp授权码
        pass: 'uozayflgdfznebfg',
    }
});

//发送登录成功的邮件通知
exports.sendMailSuccessLogin = function(email) {

    let mailOptions = {
        from: '"[麦芽糖]成绩通知系统" <1779844498@qq.com>', // sender address
        to: email, // list of receivers
        subject: '【登录成功】你已成功登录成绩通知系统', // Subject line
        html: '<h1>欢迎来到麦芽糖的邮件通知系统</h1><h2>当有新成绩时，我会第一时间通知你哒</h2>' // html body
    };

    // send mail with defined transport object
    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            return console.log(error);
        }
        console.log('发送邮件: %s', info.messageId);
        // Message sent: <04ec7731-cc68-1ef6-303c-61b0f796b78f@qq.com>
    });

}

//新成绩时,发送邮件
exports.sendMailNewGrade = function(email) {

}