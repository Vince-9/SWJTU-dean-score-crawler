const axios = require('axios');
/**
 * 这个已成功抓到数据页面
 */
const url = 'http://jwc.swjtu.edu.cn/vatuu/StudentScoreInfoAction?setAction=studentScoreQuery&viewType=studentScore&orderType=submitDate&orderValue=desc';

let Sid = 'F468BD9663EA6CDB5413A0CF239C6DAE',
    username = '2017111233';



function get() {
    axios.get(url, {
        headers: {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'Cache-Control': 'max-age=0',
            'Connection': 'keep-alive',
            'Cookie': `JSESSIONID=${Sid}; username=${username}`,
            'Host': 'jwc.swjtu.edu.cn',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36'
        }
    }).then((result) => {
        let data = result.data;
        console.log(data);
    }).catch((err) => {
        console.log(err);
    });
}

let start=new Date();
console.log(`开始时间: `,start);

get();
setInterval(() => {
    get();
    console.log(`已运行${(new Date.getTime() - start.getTime())/(60*1000)}分钟`);
}, 60000);