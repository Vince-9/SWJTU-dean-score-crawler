const cheerio = require('cheerio')
const axios = require('axios');


const url = 'http://jwc.swjtu.edu.cn/vatuu/StudentScoreInfoAction?setAction=studentScoreQuery&viewType=studentScore&orderType=submitDate&orderValue=desc';

let Sid = '155DBCF7EA02706F35DB1D947C9BA759',
    username = '2019111111';
Sid='aab';//测试并发

function get() {
    axios.get(url, {
        headers: {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'Cache-Control': 'max-age=0',
            'Connection': 'keep-alive',
            'Cookie': `JSESSIONID=${Sid}; username=${username}`,
            'Host': 'jwc.swjtu.edu.cn',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36'
        }
    }).then((result) => {
        let data = result.data;
        console.log(data);
        console.log(`${++count}`);
        getDataFromHTML(data);
    }).catch((err) => {
        console.log(err);
    });

    function getDataFromHTML(data) {
        const $ = cheerio.load(data);
        $('table#table3 tbody tr:nth-child(2) td:nth-child(3)').each((i, elem) => {
            let className = elem.children[0].data;//测绘应用程序课程设计
            console.log(`yes`);
            console.log(className);
        });

        //$.html()
    }
}

let count = 0;
let start = new Date();
console.log(`开始时间: `, start.toLocaleTimeString());
for(let i=0;i<100;i++){
    get();
    
}
setInterval(() => {
    for(let i=0;i<100;i++){
        get();
        // console.log(`${++count}`);
    }
    console.log(`已运行${((new Date().getTime() - start.getTime()) / (60 * 1000)).toFixed(0)}分钟`);
}, 60000);


