const axios = require('axios');
const querystring = require('querystring');

let sid = 'A413C89983FB9B850F1A8DF64F99DE01';
axios.post('http://jwc.swjtu.edu.cn/vatuu/UserLoginAction', querystring.stringify({
        username: '2017114305',
        password: 'TWC1779844498',
        url: 'http%3A%2F%2Fjwc.swjtu.edu.cn%2Fvatuu%2FUserLoadingAction',
        returnUrl: '',
        area: '',
        ranstring: 'OVUR'
    }), {
        headers: {
            'Host': 'jwc.swjtu.edu.cn',
            'Connection': 'keep-alive',
            'Content-Length': '136',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Origin': 'http://jwc.swjtu.edu.cn',
            'X-Requested-With': 'XMLHttpRequest',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36',
            // 'Content-Type': 'json; charset=UTF-8',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Referer': 'http://jwc.swjtu.edu.cn/service/login.html',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'Cookie': `JSESSIONID=${sid}`
        }
    })
    .then((result) => {
        console.log(result.data);
        return axios.post('http://dean.vatuu.com/vatuu/UserLoadingAction', querystring.stringify({
            "url": "http://dean.vatuu.com/vatuu/UserLoadingAction",
            "returnUrl": "",
            "loginMsg": result.data["loginMsg"]
        }), {
            headers: {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
                'Accept-Encoding': 'gzip, deflate',
                'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
                'Cache-Control': 'max-age=0',
                'Connection': 'keep-alive',
                'Content-Length': '446',
                'Content-Type': 'application/x-www-form-urlencoded',
                'Cookie': `JSESSIONID=${sid}`,
                'Host': 'jwc.swjtu.edu.cn',
                'Origin': 'http://jwc.swjtu.edu.cn',
                'Referer': 'http://jwc.swjtu.edu.cn/service/login.html?version=20192',
                'Upgrade-Insecure-Requests': '1',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36'
            }
        })
    })
    .then((result) => {
        console.log(result);
        
    })
    .catch((err) => {

    });