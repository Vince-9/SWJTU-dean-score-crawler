const axios = require('axios');
const cheerio = require('cheerio');
const fs = require('fs');

//获取登录页的图片+SID
// function getCookieAndImg(){
axios.get('http://jwc.swjtu.edu.cn/service/login.html?version=20192').then((result) => {
    // if (result.status == 200) {
        //请求成功
        let SID = result.headers['set-cookie'][0].split(';')[0].split('=')[1];
        console.log(SID);
    // }

    let imgUrl = 'http://jwc.swjtu.edu.cn/vatuu/GetRandomNumberToJPEG';//?test=1574857137927 这个串没什么用

    //已拿到SESSIONID,接下来获取图片
    return axios.get(imgUrl, {
        headers: {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
            'Accept-Encoding': 'binary',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'Cache-Control': 'max-age=0',
            'Connection': 'keep-alive',
            'Cookie': `JSESSIONID=${SID}`,
            'Host': 'jwc.swjtu.edu.cn',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36'
        }
    })
})
.then((results)=>{
    console.log(results.data);
    fs.writeFileSync('./data/randImg/test.png', results.data, 'binary');
})
.catch((err) => {
    console.log(err);
});

