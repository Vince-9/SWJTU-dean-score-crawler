const request = require('request');

let requestPromise = () => {
    return new Promise((resolve, reject) => {
        request(
            {
                url: 'http://jwc.swjtu.edu.cn/vatuu/StudentScoreInfoAction?setAction=studentScoreQuery&viewType=studentScore&orderType=submitDate&orderValue=desc',  //请求的URL
                method: 'GET',  //POST方式请求
                //encoding: null,  //由于Node默认是UTF-8，而图书馆用的GB2312，所以不进行转码
                headers: {  //请求头的设置
                    Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
                    //'Accept-Encoding': 'gzip, deflate',
                    // 'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
                    'Cache-Control': 'max-age=0',
                    'Connection': 'keep-alive',
                    Cookie: 'JSESSIONID=131D1C5E69088717D49B1170B7D0E20C; username=2017114305',
                    'Host': 'jwc.swjtu.edu.cn',
                    // 'Upgrade-Insecure-Requests': '1',
                    // 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36'
                },

            },
            function (err, res, body) {   //接收回调
                resolve(err, res, body);
            }
        );
    })
}

requestPromise().then((err, res, body) => {
    if(err){
        console.log(err);
    }
    console.log(res);
    console.log(body);
 })