const request = require('request');


let requestPromise = () => {
    return new Promise((resolve, reject) => {
        request(
            {
                url: 'http://jwc.swjtu.edu.cn/vatuu/UserLoginAction',  //请求的URL
                method: 'POST',  //POST方式请求
                //encoding: null,  //由于Node默认是UTF-8，而图书馆用的GB2312，所以不进行转码
                headers: {  //请求头的设置
                    ContentType: 'application/x-www-form-urlencoded; charset=UTF-8',
                    Cookie: 'JSESSIONID=F468BD9663EA6CDB5413A0CF239C6DAE'
                },
                form: {  //请求体，参数
                    'username': '2017114305',
                    'password': 'TWC1779844498',
                    'url': 'http://jwc.swjtu.edu.cn/index.html',
                    'returnUrl': '',
                    'area': '',
                    'ranstring': 'SMSP'
                }
            },
            function (err, res, body) {   //接收回调
                resolve([err, res, body]);
                // body = iconv.decode(body, "GB2312");  //转码

            }
        );
    })
}

requestPromise().then(([err, res, body]) => {
    // console.log(res);
    console.log(res);
    //session = res.headers['set-cookie'];  //获取set-cookie字段值
    // console.log(session);
    // if (body == 'ok') {
    //     callback({ Result: true, Session: session });
    // }
    // else {
    //     callback(false);  //回调
    // }


    // request
    // (
    //     {
    //         uri: 'http://222.24.3.7:8080/opac_two/reader/jieshulishi.jsp',  //构建请求
    //         encoding: null,  //不转码
    //         headers: {
    //             Cookie: session  //这里是关键，设置Cookie为之前请求到的以Cookie形式呈现的SessionID
    //         }
    //     }, function (err, res, body) {  //获取响应即可
    //         if (err) {
    //             callback('Server Error');
    //         }
    //     }
    // )
})

